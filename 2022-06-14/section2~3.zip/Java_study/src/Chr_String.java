
public class Chr_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch = 'A';
		int i = 'A';
		
		String str1 = ""; // �� ���ڿ�(empty string)
		String str2 = "ABCD";
		String str3 = "123";
		String str4 = str2 + str3;
		System.out.println(""+7+7);
		System.out.println(7+7+"");
	}

}
