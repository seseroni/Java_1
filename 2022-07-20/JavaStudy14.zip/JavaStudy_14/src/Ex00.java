import java.util.function.Function;

public class Ex00 {
	public static void main(String[] args) {
//		Function<String, Integer> f = (String s) -> Integer.parseInt(s);
		Function<String, Integer> f = Integer::parseInt;	// �޼��� ����
		System.out.println(f.apply("100")+200);
		
//		Supplier<MyClass> s = () -> new MyClass(); 
//		Supplier<MyClass> s = MyClass::new; 
		
		Function<Integer, MyClass> s = MyClass::new; 
		
		MyClass mc = s.apply(100); 	// MyClass ��ü ��ȯ
		System.out.println(mc.iv);
//		System.out.println(s.get());
		
		System.out.println(s.apply(200).iv);
		
//		Function<Integer, int[]> f2 = (i) -> new int[i];
		Function<Integer, int[]> f2 = int[]::new; // �޼��� ����
		int[] arr = f2.apply(100);
		System.out.println("arr.length="+arr.length);
	}
}

class MyClass{
	int iv;
	
	MyClass(int iv) {
		this.iv = iv;
	}
}