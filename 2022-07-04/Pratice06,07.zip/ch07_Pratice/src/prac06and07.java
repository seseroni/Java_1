class Outer {
	static class Inner {
//	class Inner {
		int iv = 100;
	}
}

public class prac06and07 {
	public static void main(String[] args) {
//		Outer o = new Outer();
//		Outer.Inner ii = o.new Inner();
		Outer.Inner ii = new Outer.Inner();
		System.out.println(ii.iv);
	}

}
