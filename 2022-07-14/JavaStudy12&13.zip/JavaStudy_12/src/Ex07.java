class Parent {
	void parentMethod() { }
}
class Child extends Parent {
	@Override
	void parentMethod() { }
//	void parentmethod() { }
}
